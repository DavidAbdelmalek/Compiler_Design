# Generated from milestone_1.g4 by ANTLR 4.7.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .milestone_1Parser import milestone_1Parser
else:
    from milestone_1Parser import milestone_1Parser

# This class defines a complete listener for a parse tree produced by milestone_1Parser.
class milestone_1Listener(ParseTreeListener):

    # Enter a parse tree produced by milestone_1Parser#start.
    def enterStart(self, ctx:milestone_1Parser.StartContext):
        pass

    # Exit a parse tree produced by milestone_1Parser#start.
    def exitStart(self, ctx:milestone_1Parser.StartContext):
        pass


