// Generated from milestone_1.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link milestone_1Parser}.
 */
public interface milestone_1Listener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link milestone_1Parser#start}.
	 * @param ctx the parse tree
	 */
	void enterStart(milestone_1Parser.StartContext ctx);
	/**
	 * Exit a parse tree produced by {@link milestone_1Parser#start}.
	 * @param ctx the parse tree
	 */
	void exitStart(milestone_1Parser.StartContext ctx);
}